@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="text-3xl font-bold" style="color: #2a1a05; font-family: Georgia, serif;">
                <i class="bi bi-bell-fill me-2"></i>Notifications
            </h2>
            <p class="text-muted small">Manage your admin notifications</p>
        </div>
        <button class="btn btn-sm" style="background: linear-gradient(135deg, #2a1a05 0%, #1a0f00 100%); color: white;"
                onclick="deleteAllNotifications()">
            <i class="bi bi-trash me-1"></i>Delete All
        </button>
    </div>

    <!-- Success/Error Messages -->
    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-circle me-2"></i>{{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <!-- Filter Options -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div style="background: linear-gradient(160deg, #fdf8f0 0%, #faf3e8 100%); 
                        border: 1px solid rgba(162, 128, 81, 0.2); border-radius: 12px; padding: 16px;">
                <div class="row g-3">
                    <div class="col-md-3">
                        <select id="filterStatus" class="form-select" style="border-color: rgba(162, 128, 81, 0.3);">
                            <option value="">All Notifications</option>
                            <option value="unread">Unread Only</option>
                            <option value="read">Read Only</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="filterPriority" class="form-select" style="border-color: rgba(162, 128, 81, 0.3);">
                            <option value="">All Priorities</option>
                            <option value="high">High</option>
                            <option value="medium">Medium</option>
                            <option value="low">Low</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="filterType" class="form-select" style="border-color: rgba(162, 128, 81, 0.3);">
                            <option value="">All Types</option>
                            <option value="new_order">New Order</option>
                            <option value="new_user">New User</option>
                            <option value="report">Report</option>
                            <option value="ticket">Ticket</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-outline-secondary w-100" onclick="applyFilters()">
                            <i class="bi bi-funnel me-1"></i>Apply Filters
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Notifications Table -->
    <div style="background: white; border: 1px solid rgba(162, 128, 81, 0.2); 
                border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
        
        @if ($notifications->count() > 0)
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead style="background: linear-gradient(90deg, rgba(162, 128, 81, 0.1), rgba(162, 128, 81, 0.04)); 
                                  border-bottom: 1px solid rgba(162, 128, 81, 0.2);">
                        <tr>
                            <th style="color: #2a1a05; padding: 16px; font-weight: 600;">Type</th>
                            <th style="color: #2a1a05; padding: 16px; font-weight: 600;">Title</th>
                            <th style="color: #2a1a05; padding: 16px; font-weight: 600;">Message</th>
                            <th style="color: #2a1a05; padding: 16px; font-weight: 600; text-align: center;">Priority</th>
                            <th style="color: #2a1a05; padding: 16px; font-weight: 600;">Status</th>
                            <th style="color: #2a1a05; padding: 16px; font-weight: 600;">Date</th>
                            <th style="color: #2a1a05; padding: 16px; font-weight: 600; text-align: center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($notifications as $notification)
                            <tr style="border-bottom: 1px solid rgba(162, 128, 81, 0.1); {{ $notification->is_read ? '' : 'background: rgba(162, 128, 81, 0.04);' }}">
                                <td style="padding: 16px; color: #666;">
                                    <span class="badge" style="background-color: rgba(162, 128, 81, 0.15); color: #2a1a05;">
                                        {{ ucfirst(str_replace('_', ' ', $notification->type)) }}
                                    </span>
                                </td>
                                <td style="padding: 16px; color: #2a1a05; font-weight: 500;">
                                    {{ $notification->title }}
                                </td>
                                <td style="padding: 16px; color: #666; max-width: 300px;">
                                    <div style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                        {{ $notification->message }}
                                    </div>
                                </td>
                                <td style="padding: 16px; text-align: center;">
                                    <span class="badge" style="background-color: 
                                        @if($notification->priority === 'high')
                                            rgba(239, 68, 68, 0.1); color: #dc2626;
                                        @elseif($notification->priority === 'medium')
                                            rgba(245, 158, 11, 0.1); color: #d97706;
                                        @else
                                            rgba(34, 197, 94, 0.1); color: #16a34a;
                                        @endif
                                    ">
                                        {{ ucfirst($notification->priority) }}
                                    </span>
                                </td>
                                <td style="padding: 16px;">
                                    @if ($notification->is_read)
                                        <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Read</span>
                                    @else
                                        <span class="badge bg-warning"><i class="bi bi-circle me-1"></i>Unread</span>
                                    @endif
                                </td>
                                <td style="padding: 16px; color: #999; font-size: 13px;">
                                    {{ $notification->created_at->format('d M Y, H:i') }}
                                </td>
                                <td style="padding: 16px; text-align: center;">
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="{{ route('admin.notifications.show', $notification->id) }}" 
                                           class="btn btn-outline-primary" title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        @if (!$notification->is_read)
                                            <button class="btn btn-outline-success" 
                                                    onclick="markAsRead('{{ $notification->id }}')" 
                                                    title="Mark as read">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                        @else
                                            <button class="btn btn-outline-warning" 
                                                    onclick="markAsUnread('{{ $notification->id }}')" 
                                                    title="Mark as unread">
                                                <i class="bi bi-circle"></i>
                                            </button>
                                        @endif
                                        <a href="{{ route('admin.notifications.pdf', $notification->id) }}" 
                                           class="btn btn-outline-info" title="Download PDF">
                                            <i class="bi bi-file-pdf"></i>
                                        </a>
                                        <button class="btn btn-outline-danger" 
                                                onclick="deleteNotification('{{ $notification->id }}')" 
                                                title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div style="padding: 16px; background: rgba(162, 128, 81, 0.03); border-top: 1px solid rgba(162, 128, 81, 0.2);">
                {{ $notifications->links() }}
            </div>
        @else
            <div style="padding: 48px; text-align: center;">
                <div style="font-size: 48px; color: rgba(162, 128, 81, 0.3); margin-bottom: 16px;">
                    <i class="bi bi-inbox"></i>
                </div>
                <h5 style="color: #666; margin-bottom: 8px;">No Notifications</h5>
                <p style="color: #999;">You don't have any notifications yet</p>
            </div>
        @endif
    </div>
</div>

<script>
    function markAsRead(notificationId) {
        fetch(`{{ route('admin.notifications.read', ':id') }}`.replace(':id', notificationId), {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content,
                'Content-Type': 'application/json'
            }
        })
        .then(() => {
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Notification marked as read',
                timer: 2000,
                showConfirmButton: false
            }).then(() => location.reload());
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({ icon: 'error', title: 'Error', text: 'Failed to update notification' });
        });
    }

    function markAsUnread(notificationId) {
        fetch(`{{ route('admin.notifications.unread', ':id') }}`.replace(':id', notificationId), {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content,
                'Content-Type': 'application/json'
            }
        })
        .then(() => {
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Notification marked as unread',
                timer: 2000,
                showConfirmButton: false
            }).then(() => location.reload());
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({ icon: 'error', title: 'Error', text: 'Failed to update notification' });
        });
    }

    function deleteNotification(notificationId) {
        Swal.fire({
            title: 'Delete Notification?',
            text: 'This action cannot be undone',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#ef4444'
        }).then(result => {
            if (result.isConfirmed) {
                fetch(`{{ route('admin.notifications.delete', ':id') }}`.replace(':id', notificationId), {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content,
                        'Content-Type': 'application/json'
                    }
                })
                .then(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted',
                        text: 'Notification deleted successfully',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => location.reload());
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({ icon: 'error', title: 'Error', text: 'Failed to delete notification' });
                });
            }
        });
    }

    function deleteAllNotifications() {
        Swal.fire({
            title: 'Delete All Notifications?',
            text: 'This action cannot be undone',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete All',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#ef4444'
        }).then(result => {
            if (result.isConfirmed) {
                fetch('{{ route('admin.notifications.delete_all') }}', {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content,
                        'Content-Type': 'application/json'
                    }
                })
                .then(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted',
                        text: 'All notifications deleted',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => location.reload());
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({ icon: 'error', title: 'Error', text: 'Failed to delete notifications' });
                });
            }
        });
    }

    function applyFilters() {
        const status = document.getElementById('filterStatus').value;
        const priority = document.getElementById('filterPriority').value;
        const type = document.getElementById('filterType').value;

        let url = '{{ route('admin.notifications.index') }}?';
        if (status) url += `status=${status}&`;
        if (priority) url += `priority=${priority}&`;
        if (type) url += `type=${type}`;

        window.location.href = url;
    }
</script>
@endsection
