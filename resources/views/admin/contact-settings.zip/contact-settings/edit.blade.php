@extends('layouts.admin')

@section('content')
<div class="container">
    <h4 class="mb-3">Edit Contact Settings</h4>

    <form action="{{ route('admin.contact-settings.update') }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        {{-- Get in touch --}}
        <div class="card mb-3">
            <div class="card-header bg-secondary text-white">Get in Touch</div>
            <div class="card-body">
                <div class="mb-2">
                    <label>Title</label>
                    <input type="text" name="get_in_touch_title" class="form-control" value="{{ old('get_in_touch_title', $settings->get_in_touch_title) }}">
                </div>
                <div class="mb-2">
                    <label>Description</label>
                    <textarea name="get_in_touch_desc" class="form-control" rows="3">{{ old('get_in_touch_desc', $settings->get_in_touch_desc) }}</textarea>
                </div>
               
            </div>
        </div>
        
        {{-- Partnership --}}
        <div class="card mb-3">
            <div class="card-header bg-primary text-white">Partnership</div>
            <div class="card-body">
                <div class="mb-2">
                    <label>Title</label>
                    <input type="text" name="partnership_title" class="form-control" value="{{ old('partnership_title', $settings->partnership_title) }}">
                </div>
                <div class="mb-2">
                    <label>Description</label>
                    <textarea name="partnership_description" class="form-control" rows="3">{{ old('partnership_description', $settings->partnership_description) }}</textarea>
                </div>
                <div class="mb-2">
                    <label>Email</label>
                    <input type="email" name="partnership_email" class="form-control" value="{{ old('partnership_email', $settings->partnership_email) }}">
                </div>
            </div>
        </div>

        {{-- Sales --}}
        <div class="card mb-3">
            <div class="card-header bg-success text-white">Sales</div>
            <div class="card-body">
                <div class="mb-2">
                    <label>Title</label>
                    <input type="text" name="sales_title" class="form-control" value="{{ old('sales_title', $settings->sales_title) }}">
                </div>
                <div class="mb-2">
                    <label>Description</label>
                    <textarea name="sales_description" class="form-control" rows="3">{{ old('sales_description', $settings->sales_description) }}</textarea>
                </div>
                <div class="mb-2">
                    <label>Email</label>
                    <input type="email" name="sales_email" class="form-control" value="{{ old('sales_email', $settings->sales_email) }}">
                </div>
            </div>
        </div>

        {{-- Technical --}}
        <div class="card mb-3">
            <div class="card-header bg-info text-white">Technical Support</div>
            <div class="card-body">
                <div class="mb-2">
                    <label>Title</label>
                    <input type="text" name="technical_title" class="form-control" value="{{ old('technical_title', $settings->technical_title) }}">
                </div>
                <div class="mb-2">
                    <label>Description</label>
                    <textarea name="technical_description" class="form-control" rows="3">{{ old('technical_description', $settings->technical_description) }}</textarea>
                </div>
                <div class="mb-2">
                    <label>Email</label>
                    <input type="email" name="technical_email" class="form-control" value="{{ old('technical_email', $settings->technical_email) }}">
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="{{ route('admin.contact-settings.index') }}" class="btn btn-secondary">Back</a>
    </form>
</div>
@endsection