@extends('layouts.admin')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Contact Page Settings</h4>
        <a href="{{ route('admin.contact-settings.edit') }}" class="btn btn-primary">
             Edit Contact Settings
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="row">
        {{-- Get in touch --}}
        <div class="col-md-3">
            <div class="card h-100">
                <div class="card-header bg-secondary text-white">Get in Touch</div>
                <div class="card-body">
                    <h6>{{ $settings->get_in_touch_title ?? 'N/A' }}</h6>
                    <p>{{ $settings->get_in_touch_desc ?? 'N/A' }}</p>
                    
                </div>
            </div>
        </div>
        {{-- Partnership --}}
        <div class="col-md-3">
            <div class="card h-100">
                <div class="card-header bg-primary text-white">Partnership</div>
                <div class="card-body">
                    <h6>{{ $settings->partnership_title ?? 'N/A' }}</h6>
                    <p>{{ $settings->partnership_description ?? 'N/A' }}</p>
                    <strong>Email:</strong> {{ $settings->partnership_email ?? 'N/A' }}
                </div>
            </div>
        </div>

        {{-- Sales --}}
        <div class="col-md-3">
            <div class="card h-100">
                <div class="card-header bg-success text-white">Sales</div>
                <div class="card-body">
                    <h6>{{ $settings->sales_title ?? 'N/A' }}</h6>
                    <p>{{ $settings->sales_description ?? 'N/A' }}</p>
                    <strong>Email:</strong> {{ $settings->sales_email ?? 'N/A' }}
                </div>
            </div>
        </div>

        {{-- Technical --}}
        <div class="col-md-3">
            <div class="card h-100">
                <div class="card-header bg-info text-white">Technical Support</div>
                <div class="card-body">
                    <h6>{{ $settings->technical_title ?? 'N/A' }}</h6>
                    <p>{{ $settings->technical_description ?? 'N/A' }}</p>
                    <strong>Email:</strong> {{ $settings->technical_email ?? 'N/A' }}
                </div>
            </div>
        </div>
    </div>

    @if($settings->contact_image)
        <div class="mt-3">
            <label>Background Image:</label><br>
            <img src="{{ asset('storage/'.$settings->contact_image) }}" width="300" class="border rounded">
        </div>
    @endif
</div>
@endsection